package EyeUnderstand.model;

   public class WordVO {
   
   private String words;
   
   

	public WordVO(String words) {
		this.words = words;
	}

	public String getWords() {
		return words;
	}

	public void setWords(String words) {
		this.words = words;
	}
	
	public WordVO() {
		
	}

}